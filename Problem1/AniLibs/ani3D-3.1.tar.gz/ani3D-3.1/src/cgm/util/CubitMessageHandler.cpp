#include "CubitMessageHandler.hpp"

CubitMessageHandler::CubitMessageHandler()
{
}
CubitMessageHandler::~CubitMessageHandler()
{
}


CubitMessageErrorHandler::CubitMessageErrorHandler()
{
}
CubitMessageErrorHandler::~CubitMessageErrorHandler()
{
}
