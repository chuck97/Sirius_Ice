#ifndef CUBITBOXSTRUCT_HPP
#define CUBITBOXSTRUCT_HPP

#include "CubitVectorStruct.h"

struct CubitBoxStruct
{
  struct CubitVectorStruct minimum_;
  struct CubitVectorStruct maximum_;
};

#endif

