
#include "CubitOperationEvent.hpp"

CubitOperationEvent::CubitOperationEvent(Type type)
  : mType(type)
{
}

CubitOperationEvent::~CubitOperationEvent()
{
}
