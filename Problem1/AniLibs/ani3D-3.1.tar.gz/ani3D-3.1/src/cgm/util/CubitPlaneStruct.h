#ifndef CUBITPLANESTRUCT_HPP
#define CUBITPLANESTRUCT_HPP

#include "CubitVectorStruct.h"

struct CubitPlaneStruct
{
  struct CubitVectorStruct normal_;
  double d_;
};
#endif

