#ifndef SDL_CAMERGEPARTNER_LIST_HPP
#define SDL_CAMERGEPARTNER_LIST_HPP

#include "SDLList.hpp"
#include "CAMergePartner.hpp"

SDLListdeclare(SDLCAMergePartnerList, CAMergePartner*, merge_id, int)

#endif 

