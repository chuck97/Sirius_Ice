#ifndef CUBITVECTORSTRUCT
#define CUBITVECTORSTRUCT

struct CubitVectorStruct
{
  double xVal;
  double yVal;
  double zVal;
};

#endif

