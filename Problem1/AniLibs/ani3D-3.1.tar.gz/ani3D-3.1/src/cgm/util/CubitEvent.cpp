#include "CubitEvent.hpp"

CubitEvent::~CubitEvent()
{
}

